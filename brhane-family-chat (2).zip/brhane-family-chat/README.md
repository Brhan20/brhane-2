# Brhane Family Chat – Anleitung

Eine einfache, WhatsApp-ähnliche Familien-Messenger-App (Text-Chat in Echtzeit)
gebaut mit **Expo React Native** und **Firebase**.

Ich kann hier keine fertig kompilierte .apk-Datei erzeugen (dafür braucht es
Googles Android-Build-Server), aber du bekommst den kompletten, lauffähigen
Quellcode – und mit den Schritten unten hast du in ca. 20–30 Minuten eine
installierbare .apk auf deinem Handy.

## Was die App kann
- Registrierung / Login mit E-Mail & Passwort
- Liste aller registrierten Familienmitglieder
- Echtzeit-Text-Chat (1-zu-1) zwischen zwei Personen
- Läuft auf jedem Android-Gerät der Familie

## Schritt 1 – Firebase-Projekt erstellen (kostenlos)
1. Gehe auf https://console.firebase.google.com und logge dich mit einem
   Google-Konto ein.
2. Klicke auf **"Projekt hinzufügen"**, nenne es z. B. `brhane-family-chat`.
3. Im Projekt: **Build → Authentication → Sign-in method** → aktiviere
   **E-Mail/Passwort**.
4. Im Projekt: **Build → Firestore Database** → **Datenbank erstellen** →
   Testmodus wählen (für den Familiengebrauch ausreichend).
5. Klicke auf das Zahnrad oben links → **Projekteinstellungen** → scrolle zu
   "Meine Apps" → **Web-App hinzufügen** (</> Symbol) → Namen vergeben →
   registrieren.
6. Du bekommst ein Code-Snippet mit `apiKey`, `authDomain`, `projectId` usw.
   Diese Werte trägst du in die Datei `firebaseConfig.js` ein (die
   Platzhalter wie `DEIN_API_KEY` ersetzen).

## Schritt 2 – Projekt lokal einrichten
Auf deinem PC (Windows/Mac/Linux) benötigst du **Node.js** (Version 18+):
https://nodejs.org

```bash
# Projektordner entpacken, dann hinein wechseln
cd brhane-family-chat

# Abhängigkeiten installieren
npm install

# App zum Testen starten (Expo Go App auf dem Handy installieren)
npx expo start
```

Mit der kostenlosen **Expo Go** App (Google Play Store) kannst du den QR-Code
scannen und die App sofort testen, bevor du sie als .apk baust.

## Schritt 3 – Echte .apk-Datei bauen
1. Kostenloses Konto auf https://expo.dev erstellen.
2. In deinem Projektordner:
```bash
npm install -g eas-cli
eas login
eas build:configure
```
3. APK-Build starten:
```bash
eas build -p android --profile preview
```
   (Beim ersten Mal fragt Expo, ob ein `eas.json` mit einem "preview"-Profil
   erstellt werden soll – einfach mit "Yes" bestätigen, es erzeugt automatisch
   ein APK statt eines AAB.)
4. Der Build läuft auf Expos Servern (kostenlos, dauert ca. 10–15 Minuten).
   Am Ende bekommst du einen Download-Link zur fertigen `.apk`-Datei.
5. Diese `.apk` einfach per WhatsApp, USB oder E-Mail an alle Familienmitglieder
   schicken. Beim Installieren muss auf dem Android-Handy einmalig
   **"Installation aus unbekannten Quellen erlauben"** aktiviert werden.

## Schritt 4 – Nutzung in der Familie
- Jedes Familienmitglied installiert die .apk und registriert sich mit
  Name, E-Mail und einem selbstgewählten Passwort.
- Danach erscheinen alle registrierten Personen automatisch in der
  Kontaktliste – einfach antippen und chatten.

## Erweiterungsideen (auf Wunsch baue ich das gerne aus)
- Sprachnachrichten (wie in deiner vorherigen "Brhane Family Chat"-App)
  aufnehmen und abspielen
- Gruppenchat für die ganze Familie statt nur 1-zu-1
- Profilbilder
- Push-Benachrichtigungen bei neuer Nachricht
- App-Icon und Splash-Screen mit eigenem Familienlogo
