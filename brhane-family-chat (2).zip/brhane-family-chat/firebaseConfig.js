// firebaseConfig.js
// Hier müssen die Zugangsdaten aus deinem eigenen Firebase-Projekt eingetragen werden.
// 1. Gehe zu https://console.firebase.google.com
// 2. Erstelle ein neues Projekt (z.B. "brhane-family-chat")
// 3. Füge eine Web-App hinzu -> du bekommst die Konfigurationsdaten unten
// 4. Aktiviere in der Firebase-Console: Authentication (E-Mail/Passwort) und Firestore Database

import { initializeApp, getApps, getApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence, getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: "DEIN_API_KEY",
  authDomain: "DEIN_PROJEKT.firebaseapp.com",
  projectId: "DEIN_PROJEKT",
  storageBucket: "DEIN_PROJEKT.appspot.com",
  messagingSenderId: "DEINE_SENDER_ID",
  appId: "DEINE_APP_ID",
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

let auth;
try {
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });
} catch (e) {
  auth = getAuth(app);
}

const db = getFirestore(app);

export { app, auth, db };
